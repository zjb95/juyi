import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/pages/login'
import Index from '@/pages/index'
import Enlist from "@/pages/index/enlist"
import News from "@/pages/index/news"
import Video from "@/pages/index/video"
import Pic from "@/pages/index/pci"
import Artis from "@/pages/index/artis"
Vue.use(Router)

export default new Router({
  routes: [
  {
  	path:'/',
  	component:Login
  },
    {
      path: '/index',
      name: 'index',
      component: Index,
      children:[{
      	path:'/enlist',
      	component:Enlist
      },{
      	path:'/news',
      	component:News
      }
      ,{
        path:'/video',
        component:Video
      }
      ,{
        path:'/pic',
        component:Pic
      }
      ,{
        path:'/artis',
        component:Artis
      }]
    }
  ]
})
