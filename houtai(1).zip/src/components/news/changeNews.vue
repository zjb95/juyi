<template>
	<div>
	<div>
	  <div class="nav"> 
		<p style="font-size:20px;color:#6c6d6f;">位置:新闻管理/添加新闻</p>
		  <img src="../../assets/web/返回.png" alt="" @click="back">
		</div>
		<div class="title">
	
		   <div class="">新闻标题<input type="text" placeholder="请输入新闻标题" v-model="newsDetail.title"><span>0/30</span></div>
		  <div class="fenlei"><span>新闻分类</span>
		  <select name="" id="" v-model="listType">
		  	<option value="1">音乐</option>
		  	<option value="2">视频</option>
		  	<option value="3">综艺</option>
		  	<option value="4">影视</option>
		  </select></div>
		   </div>
		   <div class="content">
		   	<el-upload
			  class="avatar-uploader"
			  :action="upLoadurl"
			  :show-file-list="false"
			  :on-success="handleAvatarSuccess"
			  :before-upload="beforeAvatarUpload">
			  <img v-if="imageUrl" :src="imageUrl" class="avatar">
			  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
			</el-upload>
			<!-- <input type="text"> -->
			<textarea name="" id="" cols="30" rows="10"></textarea>
		   </div>
		     <div class="content">
		   	<el-upload
			  class="avatar-uploader"
			  :action="upLoadurl"
			  :show-file-list="false"
			  :on-success="handleAvatarSuccess1"
			  :before-upload="beforeAvatarUpload1">
			  <img v-if="imageUrl1" :src="imageUrl1" class="avatar">
			  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
			</el-upload>
			<!-- <input type="text"> -->
			<textarea name="" id="" cols="30" rows="10"></textarea>
		   </div>
		   <!-- <div style="margin-top:20px;"><img src="../../assets/web/继续添加内容.png" alt=""></div> -->
		   <div style="width:208px;margin:0 auto;margin-top:100px;">
		   <img src="../../assets/web/发布新闻.png" alt=""></div>

	</div>
	</div>
</template>
<script>
	export default{
		  // props:["sss"],
		  props: {
			    sss: Object ,
			    newsDetail: {
				       type: Object,
					    default: function () {
					        return {}
					    }//这样可以指定默认的值
				    }//这样可以指定传入的类型，如果类型不对，会警告
			},
		data(){
			return{
				  imageUrl: '',
				  imageUrl1: '',
				  upLoadurl:this.HOST+'/admin/Files/uploadImg',
				  titleNews:'',
				  listType:'',
				  listcreatetime:''

			}
		},
		created:function(){
			// this.newsList.title=this.titleNews
			console.log(this.newsDetail)

		},
		 methods: {
		 	
		 	back(){
			this.sss.b=true;
		 	},
		      handleAvatarSuccess(res, file,fileList) {
		        this.imageUrl = res.data;
		        // console.log( this.imageUrl )
		        this.$message({
				showClose: true,
				message: res.msg,
				type: 'success'
			});
		      },
		      beforeAvatarUpload(file) {
		        const isLt2M = file.size / 1024 / 1024 < 2;

		        if (!isLt2M) {
		          this.$message.error('上传头像图片大小不能超过 2MB!');
		        }
		        return isLt2M;
		      },
		       handleAvatarSuccess1(res, file,fileList) {
		        this.imageUrl1 = URL.createObjectURL(file.raw);
		      },
		      beforeAvatarUpload1(file) {
		        const isLt2M = file.size / 1024 / 1024 < 2;

		        if (!isLt2M) {
		          this.$message.error('上传头像图片大小不能超过 2MB!');
		        }
		        return isLt2M;
		      },
		      
    }
	}
</script>
<style scoped>
.nav{
overflow: hidden;
height:100px;
}
.nav p,.nav img{
	float: left;
}
.nav p{
	line-height: 50px;
}
.nav img{
margin-left: 50px;
margin-top: 10px;
}
.title{
overflow:hidden;
}
.title>div{
	float:left;
	font-size: 20px;
	color:#6c6d6f;
	width:70%;
}
.title .fenlei{
	float:right;
	width:18%;
}
.title>div>input{
	width:80%;
	height:40px;
	border:none;
	border: 1px solid #bfbfbf;
	margin-left: 20px;
	font-size: 20px;
	color:#6c6d6f;
}
 .fenlei select{
 	width:50%;
 	height:40px;
 	font-size: 20px;
	color:#6c6d6f;

 }
.avatar-uploader{
	width:20%;
	height:100%;
	float:left;
	  border: 1px solid #d9d9d9;
}
 /*上传头像*/
  .avatar-uploader .el-upload {
  
    cursor: pointer;
    position: relative;
    overflow: hidden;
    float:left;
   width:20%;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width:243px;
    height: 243px;
    line-height: 243px;
    text-align: center;

  }
  .avatar {
    width: 100%;
    height: 243px;
    display: block;
  }
  .content{
  	overflow:hidden;
  	margin-top: 30px;
  }
  .content textarea{
  	width:75%;
  	height:243px;
  	float:left;
  	margin-left: 25px;
  	border:none;
  	border:1px solid #d9d9d9;
  	font-size: 20px;
  	resize:none;
	color:#6c6d6f;
  }

	
</style>