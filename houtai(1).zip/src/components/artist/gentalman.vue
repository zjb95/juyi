<template>
	<div>
	<div style="width:100%;background-color:#eef0f9;">
		<div class="artis" style="width:60%;padding:20px;margin:0 auto;overflow:hidden;">
		<div style="border: 1px dashed #d9d9d9;float:left;width:45%;height:502px;overflow:hidden;margin-left:29px;">
		<el-upload
			  class="avatar-uploader"
			  action="https://jsonplaceholder.typicode.com/posts/"
			  :show-file-list="false"
			  :on-success="handleAvatarSuccess"
			  :before-upload="beforeAvatarUpload">
			  <img v-if="imageUrl" :src="imageUrl" class="avatar">
			  <div v-else style="position:relative;width:100%;">
			  	<i  class="el-icon-plus avatar-uploader-icon"></i>
			  	<img src="../../assets/web1/添加封面.png" alt="" style="position:absolute;right:20px;bottom:20px;">
			  </div>
			  
			</el-upload>
			<!-- <img style="width:100%;" src="../../assets/web1/九九.png" alt=""> -->
			
		</div>
		<div class="artisPro" >
			<p style="font-size:25px;padding:30px 0">昵称:冯郎朗</p>
			<p style="padding:30px 0">一直播ID:27283250</p>
			<p style="padding:25px 0">获奖经历</p>
			<p style="line-height:40px;">
			2016 "微博红人节" 微博新锐主播第一名<br>
			2016 百事最强音绵阳赛区第一名<br>
			2015学校华裔杯 前三名</p>
			<img src="../../assets/web1/添加简介.png" alt="" style="position:absolute;right:20px;bottom:20px;" @click="jianjie">
		</div>
		</div>
	</div>
	<div style="width:100%;min-height:100%;background-color:rgba(0,0,0,.5);position:fixed;top:0;left:0px;" v-show="show">
		<div class="hide">
		<img style="position:absolute;top:12px;right:12px;cursor:pointer;" src="../../assets/web1/加号_46.png" alt="" @click="jianjie">
		<p style="wdith:66px;line-height:66px;width:100%;background-color:#eff0f5;text-align:center;">推荐艺人简介</p>
	            <div style="" class="formdetail">
				<input type="text" placeholder="艺人昵称" v-model="artistName">
				<input type="text" placeholder="签约年份" v-model="artistYear">
				<textarea name="" id=""placeholder="填写艺人经历" v-model="artistBy"></textarea>
				<img src="../../assets/web1/完成.png" alt="">
		</div>
	</div>
	</div>
	</div>
</template>
<script>
	export default{
		data(){
			return{
				imageUrl:'',
				show:false,
				artistName:'',
				artistYear:'',
				artistBy:''


			}
		},
			methods: {
				jianjie(){
					this.show=!this.show

				},
			      handleAvatarSuccess(res, file) {
			        this.imageUrl = URL.createObjectURL(file.raw);
			      },
			      beforeAvatarUpload(file) {
			        const isLt2M = file.size / 1024 / 1024 < 2;

			        
			        if (!isLt2M) {
			          this.$message.error('上传头像图片大小不能超过 2MB!');
			        }
			        return isLt2M;
			      }
			    }
	}
</script>
<style scoped>
  .artisPro{
  	background-color:#fff;
  	height:502px;
  	box-sizing:border-box;
  	width:45%;
  	float:left;
  	padding:60px 20px;
  	margin-left:20px;
  	border:1px dashed #d9d9d9;
  	position:relative;

  }
    .avatar-uploader{
    	width:100%;
    	height:100%;
    	   border: 1px dashed #d9d9d9;
    }
  .avatar-uploader .el-upload {
 
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }

  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
width:450px;
   height:502px;
    font-size: 28px;
    color: #8c939d;

    line-height: 502px;
    text-align: center;
  }
  .avatar {
width:450px;
   height:502px;
    display: block;
  }
.hide{
	width:562px;
	height:590px;
	border:1px solid #bfbfbf;
	position: fixed;
	top:200px;
	left:50%;
	margin-left: -12.5%;
	background-color: #fff;
	text-align: center;
	padding-bottom: 30px;
}
.formdetail{
	overflow:hidden;
	padding:20px;
	box-sizing: border-box;

}
.formdetail>input{
	width:435px;
	height:41px;
	font-size: 20px;
	color:#6c6d6f;
	margin-bottom: 28px;
}
.formdetail>textarea{
	resize:none;
	width:435px;
	height:284px;
	font-size: 20px;
	color:#6c6d6f;
	margin-bottom: 30px;
}
	
</style>