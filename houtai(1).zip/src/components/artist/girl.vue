<template>
	<div>
		<ul style="overflow:hidden;height:542px;margin-left:20px;width:100%;">
		    		<li style="width:23%;height:540px;position:relative;float:left;margin-right:2%;" v-for="(item,index) in girlList" :key="index">
		    		<img style="width:100%;height:100%;" :src="item.cover_img" alt="">
		    		<div style="border-radius:3px;color:#fff;position:absolute;bottom:71px;right:0;background-color:rgba(0,0,0,.5);" v-show="show==index">
		    		<span style="display:block;padding:8px;font-size:20px;cursor: pointer;" @click="changeGirl(index,item.id)">编辑</span>
		    		<span  style="display:block;padding:8px;font-size:20px;cursor: pointer;" @click="deleteImg(item.id,item.cover_img)">删除</span></div>
		    		<div style="width:100%;position:absolute;bottom:0px;left:0;background-color:rgba(0,0,0,.5);height:66px;line-height:66px;color:#fff;"><span style="margin-left:20px;font-size:20px;font-weight:bold;float:left;">{{item.nickname}}</span><img src="../../assets/web1/更多(1).png" alt="" style="float:right;margin-top:10px;cursor: pointer;" @click="moreShow(index)"></div></li>
		    	</ul>
		    	<!-- 分页 -->
		    	<div style="float:right;margin-top:50px;">
		    	<!-- <el-pagination
				  background
				  layout="prev, pager, next"
				  :page-size="pagesize"
				  :current-page="currentPage"
				  @current-change="hanlleCurrentChange"
				  :total="count">
			</el-pagination> -->
		    	</div>


		    	<!--  -->
		    	<!-- 手写分页 -->
		    	<div style="float:right;margin-top:50px;" class="pagetion">
		    	<div @click="prev()">上一页</div>
		    	<div v-for="index in pages" @click="changePage(index)"  :key="index">{{index}}</div>
		    	<div @click="next()">下一页</div>
</div>


<div style="width:100%;min-height:100%;background-color:rgba(0,0,0,.5);position:fixed;top:0;left:0px;" v-show="!changeShow">
<div class="hide">
<img style="position:absolute;top:12px;right:12px;cursor:pointer;" src="../../assets/web1/加号_46.png" alt="" @click="closeDiv">
	<p style="wdith:66px;line-height:66px;width:100%;background-color:#eff0f5;text-align:center;">修改信息</p>
	
	<div class="hide_content">
		<div>
			<el-upload
			  class="avatar-uploader"
			  :action="uplodUrl"
			  :show-file-list="false"
			  :on-success="handleAvatarSuccess"
			  :before-upload="beforeAvatarUpload">
			  <img v-if="changeImg" :src="changeImg" class="avatar">
			  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
			</el-upload>
		</div>

	<div style="width:350px;" class="formdetail">
	<select name="" id="" v-model="sex">
	<option value='' disabled selected style='display:none;'>男/女艺人</option>  
		<option value="1">女艺人</option>
		<option value="2">男艺人</option>
	</select>
	<select name="" id="" v-model="star" placeholder="">
	<option value='' disabled selected style='display:none;'>是否推介艺人</option>  
		<option value="1">是</option>
		<option value="0">否</option>
	</select>
	<input type="text" placeholder="艺人昵称" v-model="nickname">
	<input type="text" placeholder="签约年份" v-model="year">
	<textarea name="" id="" cols="30" rows="10" placeholder="填写艺人经历" v-model="undergo"></textarea>
		
	</div>
	</div>
	<div style="width:164px;height:51px;background-color:rgb(104,143,211);color:#fff;line-height:51px;border-radius:3px;margin:0 auto;font-size:20px;" @click="changeInfo">修改艺人信息</div>
	
</div>
</div>
	</div>
</template>
<script>
export default {
  props: {
    sex: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {
      active: { background: " #5CACEE" },
      show: 0,
      pagesize: 4,
      currentPage: 1,
      count: 0,
      pages: 0,
      changeShow: true,
      imageUrl: "",
      nickname: "",
      year: "",
      undergo: "",
      star: "",
      girlList: [],
      changeImg: "",
      changeID: 0,
      uplodUrl: this.HOST + "/admin/Files/uploadImg"
    };
  },
  created: function() {
    console.log(this.sex);
    this.getData();
  },
  methods: {
    getData() {
      this.$axios
        .post(this.HOST + "/admin/Artist/getList", {
          page: this.currentPage,
          pagecount: this.pagesize,
          sex: this.sex,
          type: 1
        })
        .then(res => {
          this.girlList = res.data.data.list;
          this.count = res.data.data.total_num;
          this.pages = res.data.data.total_page;
        });
    },
    prev() {
      if (this.currentPage > 1) {
        this.changePage(this.currentPage - 1);
      }
    },
    next() {
      if (this.currentPage < this.pages) {
        this.changePage(this.currentPage + 1);
      }
    },
    changePage(a) {
      this.currentPage = a;
      this.getData();
      console.log(this.pages);
    },
    moreShow(index) {
      this.show = index;
    },
    changeGirl(a, b) {
      this.$axios
        .post(this.HOST + "/admin/Artist/getInfo", {
          id: b
        }) .then(res => {
          this.changeImg = res.data.data.cover_img;
          this.sex = res.data.data.sex;
          this.nickname = res.data.data.nickname;
          this.year = res.data.data.contract_year;
          this.undergo = res.data.data.undergo;
          this.changeID = res.data.data.id;
        });

      this.changeShow = !this.changeShow;
    },
    changeInfo() {
      var that = this;
      this.$axios
        .post(this.HOST + "/admin/Artist/edit", {
          id: this.changeID,
          nickname: this.nickname,
          cover_img: this.changeImg,
          contract_year: this.year,
          undergo: this.undergo,
          star: this.star
        })
        .then(res => {
          if (res.data.status == 1) {
            that.$message({
              message: res.data.message,
              type: "success"
            });
            this.show = !this.show;
            setTimeout(function() {
              location.reload();
            }, 300);
          } else {
            that.$message({
              message: res.data.message,
              type: "error"
            });
          }
        });
    },
    closeDiv() {
      this.changeShow = !this.changeShow;
    },
    handleAvatarSuccess(res, file) {
      this.changeImg = res.data;
    },
    beforeAvatarUpload(file) {
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      return isLt2M;
    },
    hanlleCurrentChange(val) {
      this.currentPage = val;
      this.getData();
    },

    deleteImg(a, b) {
      var that = this;
      this.$axios
        .post(this.HOST + "/admin/Artist/del", {
          id: a,
          cover_img: b
        })
        .then(res => {
          if (res.data.status == 1) {
            that.$message({
              message: res.data.message,
              type: "success"
            });
            setTimeout(function() {
              location.reload();
            }, 300);
          } else {
            that.$message({
              message: res.data.message,
              type: "error"
            });
          }
        });
    }
  }
};
</script>
<style scoped>
.hide {
  width: 725px;
  height: 734px;
  border: 1px solid #bfbfbf;
  position: fixed;
  top: 100px;
  left: 50%;
  margin-left: -25%;
  background-color: #fff;
  text-align: center;
}
.hide_content {
  overflow: hidden;
  padding: 20px;
  box-sizing: border-box;
}
.hide_content > div {
  float: left;
}
.formdetail {
  margin-left: 20px;
}
.formdetail > input,
.formdetail > select {
  width: 345px;
  height: 41px;
  font-size: 20px;
  color: #6c6d6f;
  margin-bottom: 28px;
}
.formdetail > textarea {
  resize: none;
  width: 345px;
  height: 247px;
  font-size: 20px;
  color: #6c6d6f;
}
/**上传头像*/
.avatar-uploader {
  width: 285px;
  height: 540px;
  border: 1px dashed #d9d9d9;
}
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 285px;
  margin-top: 200px;
  font-size: 50px;
  text-align: center;
}
.avatar {
  width: 285px;
  height: 540px;
  display: block;
}
.pagetion {
  overflow: hidden;
}
.pagetion > div {
  float: left;
  margin-left: 10px;
  padding: 5px 10px;
  border: 1px solid #ddd;
  text-align: center;
  cursor: pointer;
}
.active {
  background: #5cacee;
}
</style>