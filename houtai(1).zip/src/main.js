// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import $ from 'jquery'
import Axios from "axios"
import ElementUI from 'element-ui';
import {Upload,  Container,DatePicker, Pagination ,Tabs,  TabPane} from 'element-ui'
import VueAwesomeSwiper from 'vue-awesome-swiper'
import 'element-ui/lib/theme-chalk/index.css';

// 分页插件
// import pageination from 'vue_pageination';
// Vue.use(pageination);

require('swiper/dist/css/swiper.css')

Vue.use(VueAwesomeSwiper)
Vue.use(ElementUI);
Vue.use(Container);

Vue.use(DatePicker);
Vue.use(Upload);
Vue.use(Pagination);
Vue.use(Tabs);
Vue.use(TabPane);

Vue.config.productionTip = false
Vue.prototype.$axios = Axios
Vue.prototype.HOST='/api'
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
