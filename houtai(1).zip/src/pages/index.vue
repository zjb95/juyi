<template>
  <div class="hello">
  <el-container>
  <el-aside width="200px">
  <img src="../assets/web/矢量智能对象.png" height="105" width="116" alt="" style="margin-top:50px;">
       <ul class="left_nev">
           <li v-for="(val,index) in router" :key="index"><router-link exact :to="val.to">{{val.name}}</router-link></li>
       </ul>
  </el-aside>
  <el-container>
    <el-header>
        <div class="header">
            <div class="header_time">
               <span>{{time}}</span>,<span>{{weekday}}</span>,<span>{{hour}}</span>
            </div>
            <div class="loginname">
            <img src="../assets/web/矢量智能对象_27.png" alt="" style="float:left;margin-right:20px;">
            <span style="margin-right:30px;float:left;" >聚宜文化传媒</span>
            <span @click="loginOut">退出</span>
            </div>
        </div>
   </el-header>
    <el-main>
       <router-view></router-view>
     </el-main>
  </el-container>
</el-container>
  </div>
</template>
<script>

export default {
  name: 'Index',

  data () {
    return {
time:'',
weekday:'',
hour:'',
router:[
{to:'/enlist',name:'招募管理'},
            {to:'/news',name:'新闻管理'},
            {to:'/video',name:'视频管理'},
            {to:'/pic',name:'图集管理'},
            {to:'/artis',name:'艺人管理'}
            ]
   }
  },
  created:function(){
        //获取当前时间，格式YYYY-MM-DD

        var date = new Date();
        var seperator1 = "-";
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var hour = date.getHours();
         var minute = date.getMinutes();
      
      
        var weekday=new Array(7)
        weekday[0]="星期天"
        weekday[1]="星期一"
        weekday[2]="星期二"
        weekday[3]="星期三"
        weekday[4]="星期四"
        weekday[5]="星期五"
        weekday[6]="星期六"

        this.weekday=weekday[date.getDay()]
        this.hour=hour+':'+minute
        this.time=year + seperator1 + month + seperator1 + strDate;

  },
  methods:{
    loginOut(){
      this.$router.push({path:"/"})
    }

    
   
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.hello{
  font-family: "MicrosoftYaHei";
}
.header_time{
  float:left;
}
.header_time span{
  margin-left: 10px;
}
.loginname{
  float:right;
  overflow:hidden;
}
.header{
  overflow:hidden;
}
 .el-header {
    background-color: #eff0f5;
    color: #333;
    line-height: 60px;
  }
  
  .el-aside {
    background-color:#303030;
    color: #333;
    text-align: center;
    min-height:890px;
    height:100%;
    /*line-height: 200px;*/
  }
   .left_nev{
    margin-top:50px;
   }
  .left_nev li{
    width:100%;
    height:66px;
    line-height: 66px;
  
  }
    .left_nev li a{
        color:#fff;
        display:block;
        text-decoration: none;
          width:98.5%;
          height:66px;
          line-height: 66px;
    }
  
  .el-main {
    background-color: #fff;
    color: #333;
  }
    body > .el-container {
    margin-bottom: 40px;
  }
  
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
  .router-link-active{
  background-color: #212121;
  border-right:3px solid #cda45a;
}
</style>
