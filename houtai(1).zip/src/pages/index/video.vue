<template>
	<div>	
	   <div>
	        <div>
	          <img src="../../assets/web1/添加新视频.png" height="51" width="164" alt="" @click="upLoad"></div>
	           <div style="margin-top:40px">
	        	<ul>
	        	   <li style="width:20%;height:255px;overflow:hidden;position:relative;" v-for="(item,index) in videoList">
	        	   <a :href="item.video_path" target="_Blank">
	        	            <img style="width:100%;height:100%;" :src="item.cover_img" alt="">
	        		<img src="../../assets/web1/矩形10拷贝5.png" alt="" style="position:absolute;left:50%;top:100px;">
	        		</a>
	        		<div style="background-color:rgba(0,0,0,.5);width:100%;height:52px;line-height:52px;padding-left:20px;position:absolute;bottom:0px;left:0px;color:#fff;box-sizing:border-box;">
	        		<span style="float:left;">{{item.title_name}}</span><img src="../../assets/web1/删除拷贝_48.png" style="float:right" alt="" @click="deleteVideo(item.id,item.cover_img,item.video_path)"></div>
	        		</li>
	        	</ul>
	        </div>
	  </div>



	  <!-- 分页 -->
<div style="float:right;margin-top:30px;">
	  <el-pagination
  background
  layout="prev, pager, next"
  :page-size="pagesize"
  :current-page="currentPage"
  @current-change="hanlleCurrentChange"
:total="count"
>
</el-pagination>
<!-- <component is="Fenye"></component> -->

<!-- <mo-paging 
            :page-index="currentPage" 
            :total="count" 
            :pages="countnNum"
            :page-size="pagesize" 
            @change="hanlleCurrentChange">
            </mo-paging> -->



</div>
	  <!-- 隐藏div -->
            <div style="width:100%;min-height:100%;background-color:rgba(0,0,0,.5);position:fixed;top:0;left:0px;" v-show="!show">
            <div class="hide">
          <img style="position:absolute;top:25px;right:12px;cursor:pointer;" src="../../assets/web1/加号_46.png" alt="" @click="upLoad">
	<p style="line-height:66px;background-color:#eff0f5;text-align:center;">添加新视频</p>
	<div class="hide_content">
	<el-upload
		  class="avatar-uploader"
		  :action="videoUrl"
		  :show-file-list="false"
		  :on-success="handleAvatarSuccess"
		  :before-upload="beforeAvatarUpload">
		  <video v-if="imageUrl1" :src="imageUrl1" class="avatar"></video>
		  <!-- <img v-if="imageUrl1" :src="imageUrl1" class="avatar"> -->
		  <div v-else>
		  	  <i  class="el-icon-plus avatar-uploader-icon"></i>
		  选择视频
		  </div>
	</el-upload>
	<el-upload
		  class="avatar-uploader"
		  :action="updateImg"
		  :show-file-list="false"
		  :on-success="handleAvatarSuccess1"
		  :before-upload="beforeAvatarUpload1">
		  <img v-if="imageUrl" :src="imageUrl" class="avatar">
		  <div v-else >
		  	  <i class="el-icon-plus avatar-uploader-icon"></i>
		  选择封面图片
		  </div>
	</el-upload>
		<input type="text" placeholder="视频名称" v-model="videoName">
		<img src="../../assets/web1/发布视频.png" alt="" style="margin:20px auto;" @click="addVideo">
	<div>
	
	</div>
	</div>
</div>
</div>
	</div>
</template>
<script>
import MoPaging  from '../../components/fenye.vue'
	export default{
		components:{
			MoPaging 
		},
		data(){
			return{
				pagesize:8,
				currentPage:1,
				count:0,
				countnNum:0,
				flag:false,
				imageUrl:'',
				imageUrl1:'',
				videoName:'',
				show:true,
				videoUrl:this.HOST+"/admin/Files/uploadVideo",
				updateImg:this.HOST+"/admin/Files/uploadImg",
				video:'',
				videoList:[],
				videoNum:0,
				  showPrevMore : false,
			            showNextMore : false


			}
		},
		watch:{


		},
		mounted(){
			this.getData();
			console.log(this.countnNum)

		},
		created:function(){
			this.getData();
			console.log(this.countnNum)
			
                       },
		methods:{
			upLoad(){
				this.flag=!this.flag;
				this.show=!this.show
			},
			// 分页
			hanlleCurrentChange(val){
				   this.currentPage = val;
				   console.log(this.currentPage)
			              this.getData();
			},
		         getData(){
			      	this.$axios.post(this.HOST+'/admin/Video/getList',{
			      		page:this.currentPage,
			      		pagecount:this.pagesize
			      	}).then((res)=>{
			      		this.videoList=res.data.data.list
			      		this.count=res.data.data.total_num
			      		this.countnNum=res.data.total_page
			      		console.log(this.count)
			      		console.log(res.data.data)

			      	})

			      },
		
			// 上传视频
		            handleAvatarSuccess(res, file) {
			        this.imageUrl1 = res.data;
			        // console.log(res)
			      },
			      beforeAvatarUpload(file) {
				        const isLt2M = file.size / 1024 / 1024 < 100;
				        if (!isLt2M) {
				          this.$message.error('上传视频大小不能超过 100MB!');
				        }
				        return  isLt2M;
			      },
			      // 上传头像
			       handleAvatarSuccess1(res, file) {
			       	// console.log(res.data)
			        this.imageUrl =res.data;
			      },
			      beforeAvatarUpload1(file) {
				        const isLt2M = file.size / 1024 / 1024 < 2;
				        if (!isLt2M) {
				          this.$message.error('上传头像图片大小不能超过 2MB!');
				        }
				        return  isLt2M;
			      },
			   

			      // 删除视频
			      deleteVideo(a,b,c){
			      	var that=this;
			      	this.$axios.post(this.HOST+'/admin/Video/del',{
			      		id:a,
			      		video_path:b,
			      		cover_img:c
			      	}).then((res)=>{
			      		if(res.data.status==1){
			      			  that.$message({
							message: res.data.message,
							type: 'success'
						});
			      			 
			      			 setTimeout(function() {
							location.reload();
						}, 300)
			      			  

			      		}else{
			      			  that.$message({
							message: res.data.message,
							type: 'error'
						});
			      		}

			      	})
			      },
			      addVideo(){
			      	var that=this;
			      	this.$axios.post(this.HOST+'/admin/Video/add',{
			      		title_name:this.videoName,
			      		video_path:this.imageUrl1,
			      		cover_img:this.imageUrl
			      	}).then((res)=>{
			      		if(res.data.status==1){
			      			  that.$message({
							message: res.data.message,
							type: 'success'
						});
			      			  this.show=!this.show;
			      			 setTimeout(function() {
							location.reload();
						}, 100)
			      			  

			      		}else{
			      			  that.$message({
							message: res.data.message,
							type: 'error'
						});
			      		}

			      	})

			      },
			      
		}
	}
</script>
<style scoped>
ul{
	overflow:hidden;
}
li{
	float:left;
	margin-right: 5%;
	margin-top:32px;
}
.hide{
	width:482px;
	height:440px;
	border:1px solid #bfbfbf;
	position: fixed;
	top:200px;
	left:50%;
	margin-left:-12.5%;
	background-color: #fff;
}
/*上传头像*/
  .avatar-uploader{
   width:200px;
    height:200px;
       border: 1px dashed #d9d9d9;
       margin-top:20px;
        float:left;
        margin-left:25px;
  }
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    width:200px;
    height:200px;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;


  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size:50px;
    color: #8c939d;
     width:200px;
    height:150px;
    line-height: 150px;
    text-align: center;
  }
  .avatar {
   width:200px;
    height:200px;
    display: block;
  }
    .hide_content{
    	text-align: center;
    }
  .hide_content input{
  	width:345px;
  	height:41px;
  	font-size: 20px;
  	margin-top:20px;
  }
   .hide_content img{
   	display: block;
   }


   /*分页*/
   .mo-paging {
    display: inline-block;
    padding: 0;
    margin: 1rem 0;
    font-size: 0;
    list-style: none;
    user-select: none;
}
   .paging-item {
        display: inline;
        font-size: 14px;
        position: relative;
        padding: 6px 12px;
        line-height: 1.42857143;
        text-decoration: none;
        border: 1px solid #ccc;
        background-color: #fff;
        margin-left: -1px;
        cursor: pointer;
        color: #0275d8;
    }
           .paging-item:first-child {
            margin-left: 0;
        }
       .paging-item::hover {
            background-color: #f0f0f0;
            color: #0275d8;
        }
       .paging-item .paging-item--disabled,
        .paging-item.paging-item--more{
            background-color: #fff;
            color: #505050;
        }
      
       .paging-item--disabled {
            cursor: not-allowed;
            opacity: .75;
        }
       .paging-item--more,
        .paging-item--current {
            cursor: default;
        }
     
       .paging-item--current {
            background-color: #0275d8;
            color:#fff;
            position: relative;
            z-index: 1;
            border-color: #0275d8;
        }
  

</style>