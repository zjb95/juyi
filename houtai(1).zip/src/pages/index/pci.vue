<template>
	<div>
		 <div>
	          <img src="../../assets/web1/添加图片.png" height="51" width="164" alt="" @click="addPic"></div>
	        <div style="margin-top:40px">
	        	<ul>
	        	   <li style="width:23%;height:255px;overflow:hidden;position:relative;" v-for="(item,index) in imgList">
	        	   <img style="width:100%;min-height:100%;" :src="item.image_path" alt="">
	        		<div style="background-color:rgba(0,0,0,.5);width:100%;height:52px;line-height:52px;padding-left:20px;position:absolute;bottom:0px;left:0px;color:#fff;box-sizing:border-box;">
	        		<span style="float:left;">{{item.content}}</span><img src="../../assets/web1/删除拷贝_48.png" style="float:right;cursor:pointer;" alt="" @click="deleteImg(item.id,item.image_path)"></div></li>
	        	</ul>
	        </div>
	

	<div style="float:right;margin-top:30px;">
	  <el-pagination
		  background
		  layout="prev, pager, next"
		  :page-size="pagesize"
		  :current-page="currentPage"
		  @current-change="hanlleCurrentChange"
		:total="count"
		>
      </el-pagination>


</div>
	 


<div style="width:100%;min-height:100%;background-color:rgba(0,0,0,.5);position:fixed;top:0;left:0px;" v-show="!show">
<div class="hide">
<img style="position:absolute;top:25px;right:12px;cursor:pointer;" src="../../assets/web1/加号_46.png" alt="" @click="addPic">
	<p style="line-height:66px;background-color:#eff0f5;text-align:center;">添加图片</p>
	
	<div class="hide_content">
	<el-upload
		  class="avatar-uploader"
		  :action="uploadUrl"
		  :show-file-list="false"
		  :on-success="handleAvatarSuccess"
		  :before-upload="beforeAvatarUpload">
		  <img v-if="imageUrl" :src="imageUrl" class="avatar">
		  <div v-else>	
		   <i  class="el-icon-plus avatar-uploader-icon"></i>
		  选择封面图片
		  </div>
		 
	</el-upload>
		<input type="text" placeholder="图片标题" style="" v-model="imgName">
		<img  src="../../assets/web1/发布艺人.png" alt="" @click="addArtist">
	<div>
	
	</div>
	</div>
</div>
</div>
         

	</div>
</template>
<script>
	export default{
		data(){
			return{
				pagesize:8,
				currentPage:1,
				count:0,
				countnNum:0,
				imageUrl:'',
				show:true,
				uploadUrl:this.HOST+"/admin/Files/uploadImg",
				imgName:'',
				imgList:[]

			}
		},
		created:function(){
			this.getData();

		},
		methods:{
			addPic(){
				this.show=!this.show;
			},
			hanlleCurrentChange(val){
				   this.currentPage = val;
				   console.log(this.currentPage)
			              this.getData();
			},
			deleteImg(a,d){
				var that=this;
			      	this.$axios.post(this.HOST+'/admin/Image/del',{
			      		id:a,
			      		image_path:d
			      	}).then((res)=>{
			      		if(res.data.status==1){
			      			  that.$message({
							message: res.data.message,
							type: 'success'
						});
			      			
			      			 setTimeout(function() {
							location.reload();
						}, 300)
			      			  

			      		}else{
			      			  that.$message({
							message: res.data.message,
							type: 'error'
						});
			      		}

			      	})

			},
			  handleAvatarSuccess(res, file) {
			  	console.log(res)
			        this.imageUrl = res.data;
			      },
			      beforeAvatarUpload(file) {
				        const isLt2M = file.size / 1024 / 1024 < 2;
				        if (!isLt2M) {
				          this.$message.error('上传头像图片大小不能超过 2MB!');
				        }
				        return  isLt2M;
			        
			      },
			      addArtist(){
			      		var that=this;
			      	this.$axios.post(this.HOST+'/admin/Image/add',{
			      		content:this.imgName,
			      		image_path:this.imageUrl
			      	}).then((res)=>{
			      		if(res.data.status==1){
			      			  that.$message({
							message: res.data.message,
							type: 'success'
						});
			      			  this.show=!this.show;
			      			 setTimeout(function() {
							location.reload();
						}, 300)
			      			  

			      		}else{
			      			  that.$message({
							message: res.data.message,
							type: 'error'
						});
			      		}

			      	})

			      },
			      getData(){
			      		this.$axios.post(this.HOST+'/admin/Image/getList',{
			      		page:this.currentPage,
			      		pagecount:this.pagesize
			      	}).then((res)=>{
			      		this.imgList=res.data.data.list
			      		this.count=res.data.data.total_num
			      		this.countnNum=res.data.total_page
			      		console.log(this.imgList)
			      		

			      	})

			      }
			}
		
	}
</script>
<style scoped>
ul{
	overflow:hidden;
}
li{
	float:left;
	margin-right:2%;
	margin-top:32px;
}

/*上传头像*/

 .avatar-uploader{
   width:345px;
    height:255px;
 border: 1px dashed #d9d9d9;
 margin:20px auto;
 overflow:hidden;
  }
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    width:100%;
    height:100%;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;

  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size:50px;
    color: #8c939d;
 width:345px;
    height:200px;
    line-height: 200px;
    text-align: center;
  }
  .avatar {
  width:100%;
height:100%;
    display: block;
  }
.hide{
	width:482px;
	height:512px;
	border:1px solid #bfbfbf;
	position: fixed;
	top:200px;
	left:50%;
	margin-left:-12.5%;
	background-color: #fff;
}
.hide_content{
	text-align: center;
}
.hide_content input{
	display: block;
	margin-left: 68px;
	width:345px;
	height:41px;
	font-size:20px;
	margin-bottom:20px;
}
</style>