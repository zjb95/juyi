<template>
	<div>
	<div>
	<img src="../../assets/web1/添加艺人.png" alt="" style="float:right;" @click="dianji">
	<div class="tabs">
		<el-tabs v-model="activeName2" type="card" @tab-click="handleClick">
		<!-- 女艺人 -->
		    <el-tab-pane label="女艺人" name="first">
		    	
		    	<Girl :sex="1"/>

		    
		    </el-tab-pane>
		    <!-- 女艺人推荐 -->
		    <!-- <el-tab-pane label="女艺人推荐" name="second">
				<component  is="Gentalman"></component>
		    </el-tab-pane> -->
		    <!-- 男艺人 -->
		    <el-tab-pane label="男艺人" name="third">
		    <Girl :sex="2"></Girl>
		    	<!-- <ul style="overflow:hidden;height:542px;margin-left:20px;width:100%;">
		    		<li style="width:20%;height:540px;position:relative;float:left;margin-right:40px;" v-for="itenm in 4">
		    		<img style="width:100%"src="../../assets/web/77oba.png" alt="">
		    		<div style="border-radius:3px;color:#fff;position:absolute;bottom:71px;right:0;background-color:rgba(0,0,0,.5);" v-show="!show">
		    		<span style="display:block;padding:8px;font-size:20px;cursor: pointer;">编辑</span>
		    		<span  style="display:block;padding:8px;font-size:20px;cursor: pointer;">删除</span></div>
		    		<div style="width:100%;position:absolute;bottom:0px;left:0;background-color:rgba(0,0,0,.5);height:66px;line-height:66px;color:#fff;"><span style="margin-left:20px;font-size:20px;font-weight:bold;float:left;">阳阳</span><img src="../../assets/web1/更多(1).png" alt="" style="float:right;margin-top:10px;cursor: pointer;" @click="moreShow"></div></li>
		    	</ul>
		    	<div style="float:right;margin-top:50px;">
		    			<el-pagination
				  background
				  layout="prev, pager, next,jumper"
				  :page-size="pagesize"
				  :current-page="currentPage"
				  @size-change="handleSizeChange"
				  @current-change="hanlleCurrentChange"
				  :page-sizes="[10, 20, 30, 40]"
				  :total="100">
			</el-pagination>
		    	</div> -->
		    </el-tab-pane>
		    <!-- 男艺人推荐 -->
		   <!--  <el-tab-pane label="男艺人推荐" name="fourth">
		        <component  is="Gentalman"></component>
		     </el-tab-pane> -->
		  </el-tabs>

	</div>
		  
	</div>
	<!-- 隐藏div -->
<div style="width:100%;min-height:100%;background-color:rgba(0,0,0,.5);position:fixed;top:0;left:0px;" v-show="!flag">
<div class="hide">
<img style="position:absolute;top:12px;right:12px;cursor:pointer;" src="../../assets/web1/加号_46.png" alt="" @click="dianji">
	<p style="wdith:66px;line-height:66px;width:100%;background-color:#eff0f5;text-align:center;">添加艺人</p>
	
	<div class="hide_content">
		<div>
			<el-upload
			  class="avatar-uploader"
			  :action="upLoadurl"
			  :show-file-list="false"
			  :on-success="handleAvatarSuccess"
			  :before-upload="beforeAvatarUpload">
			  <img v-if="imageUrl" :src="imageUrl" class="avatar">
			  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
			</el-upload>
		</div>

	<div style="width:350px;" class="formdetail">
	<select name="" id="" v-model="sex">
		<option value="1">女艺人</option>
		<option value="2">男艺人</option>
	</select>
	<input type="text" placeholder="艺人昵称" v-model="nickname">
	<input type="text" placeholder="签约年份" v-model="year">
	<textarea name="" id="" cols="30" rows="10" placeholder="填写艺人经历" v-model="undergo"></textarea>
		
	</div>
	</div>
	<img src="../../assets/web1/发布艺人.png" alt="" @click="addArist">
</div>
</div>
	</div>
</template>
<script>
import Gentalman from "../../components/artist/gentalman";
import Girl from "../../components/artist/girl";
export default {
  components: {
    Gentalman,
    Girl
  },
  data() {
    return {
      sex: 0,
      activeName2: "first",
      show: true,
      flag: true,
      imageUrl: "",
      pagesize: 10,
      currentPage: 1,
      sex: 0,
      nickname: "",
      year: "",
      undergo: "",
      upLoadurl: this.HOST + "/admin/Files/uploadImg"
    };
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab.index);
    },
    addArist() {
      var that = this;
      this.$axios
        .post(this.HOST + "/admin/Artist/add", {
          cover_img: this.imageUrl,
          sex: this.sex,
          nickname: this.nickname,
          contract_year: this.year,
          undergo: this.undergo
        })
        .then(res => {
          if (res.data.status == 1) {
            that.$message({
              message: res.data.message,
              type: "success"
            });
            this.show = !this.show;
            setTimeout(function() {
              location.reload();
            }, 300);
          } else {
            that.$message({
              message: res.data.message,
              type: "error"
            });
          }
        });
    },
    moreShow() {
      this.show = !this.show;
    },
    dianji() {
      this.flag = !this.flag;
    },
    handleAvatarSuccess(res, file) {
      console.log(res.data);
      this.imageUrl = res.data;
    },
    beforeAvatarUpload(file) {
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      return isLt2M;
    },
    hanlleCurrentChange(val) {
      this.currentPage = val;
      // this.getData(this.currentPage, this.pagesize);
    },
    handleSizeChange() {}
  }
};
</script>
<style scoped>
.tabs {
  float: left;
  width: 100%;
}
.hide {
  width: 725px;
  height: 734px;
  border: 1px solid #bfbfbf;
  position: fixed;
  top: 200px;
  left: 50%;
  margin-left: -12.5%;
  background-color: #fff;
  text-align: center;
}
.hide_content {
  overflow: hidden;
  padding: 20px;
  box-sizing: border-box;
}
.hide_content > div {
  float: left;
}
.formdetail {
  margin-left: 20px;
}
.formdetail > input,
.formdetail > select {
  width: 345px;
  height: 41px;
  font-size: 20px;
  color: #6c6d6f;
  margin-bottom: 28px;
}
.formdetail > textarea {
  resize: none;
  width: 345px;
  height: 320px;
  font-size: 20px;
  color: #6c6d6f;
}
/*上传头像*/
.avatar-uploader {
  width: 285px;
  height: 540px;
  border: 1px dashed #d9d9d9;
}
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 285px;
  margin-top: 200px;
  font-size: 50px;
  text-align: center;
}
.avatar {
  width: 285px;
  height: 540px;
  display: block;
}

/*切换*/
.el-tabs--card > .el-tabs__header .el-tabs__item.is-active {
  background: #f6f7fc;
}
.el-tabs__item.is-active {
  color: #000 !important;
}
</style>