<template>
	<div>
	<Writenews :sss="flag" v-show="!flag.a"/>
	<Changenews :sss="flag" :news-detail="newsdetail" v-show="!flag.b"/>
	<div v-show="flag.a&&flag.b">
	     <p><img src="../../assets/web/添加新内容.png" alt="" @click="tianjia"></p>
		<div class="news-content">
			<ul class="news-title">
				<li style="width:5%;">选择</li>
				<li style="width:7%;">序号</li>
				<li style="width:37%;">标题内容</li>
				<li style="width:14%;">分类</li>
				<li style="width:13.8%;">发布时间</li>
				<li style="width:17.8%;">操作</li>
			</ul>
			<ul v-for="(item,index) in newslist" class="newslist" :key="index">
				<li style="width:5%;text-align:center;">
					<input type="checkbox" v-model="choseAll" :value="item.id">
				</li>
				<li style="width:7%;text-align:center;">{{item.id}}</li>
				<li style="width:37%;">{{item.title_name}}</li>
				<li style="width:14%;text-align:center;">{{item.type_text}}</li>
				<li style="width:13.8%;text-align:center;">{{item.create_time}}</li>
				<li style="width:17.8%;text-align:center;">
				<img style="margin-left:20%;margin-top:5px;cursor:pointer;" src="../../assets/web/浏览拷贝.png" alt="" @click="lookNews(item.id)">
				<img style="margin-top:5px;cursor:pointer;" src="../../assets/web/编辑拷贝.png" alt="" @click="changeNews(item.id)">
				</li>
			</ul>
			<div class="news-footer"><input type="checkbox" style="margin-left:2%;" :checked="allList" @click="checkedAll">
			  <img src="../../assets/web/全选.png" alt="" style="margin-left:2%;margin-top:12px;">
			  <img src="../../assets/web/删除拷贝2.png" alt="" style="margin-left:2%;margin-top:12px;" @click="delNews()">
			</div>
		</div>
			<!-- 分页 -->
				<el-pagination
				  background
				  layout="prev, pager, next,jumper"
				  :page-size="pagesize"
				  :current-page="currentPage"
				  @current-change="hanlleCurrentChange"
				  :page-sizes="[10, 20, 30, 40]"
				  :total="count">
				</el-pagination>
		</div>

		

		<!-- 隐藏浏览新闻-->
<div style="width:100%;min-height:100%;background-color:rgba(0,0,0,.5);position:fixed;top:0px;left:0px;" v-show="!show">
<div class="hide">
	<p style="font-size:20px;wdith:66px;line-height:66px;width:1000px;background-color:#eff0f5;text-align:center;">浏览新闻</p>
	<img style="position:absolute;top:12px;right:12px;cursor:pointer;" src="../../assets/web/加号.png" alt="" @click="show=true">
	<div class="hide_content">
	<p>{{newsdetail.title_name}}</p>
	<p>
	<span>点击次数:12121</span><span>更新时间:{{newsdetail.update_time}}</span>
	</p>
	<p>{{newsdetail.content}}</p>
		<div style="width:500px;height:400px;overflow:hidden;margin:0 auto;"><img style="width:100%" src="../../assets/web/77oba.png" alt="" ></div>
	
	</div>
</div>
</div>

	</div>
</template>
<script>
import Writenews from '../../components/writenews.vue'
import Changenews from '../../components/news/changeNews.vue'
	export default{
		name:'news',
		components:{
			Writenews,
			Changenews
		},
		data(){
			return{
				pagesize:10,
				currentPage:1,
				flag:{a:true,b:true},
				All1:[],
				allList:false,
				show:true,
				newsdetail:{},
				newslist:[],
				count:0,
				choseAll:[],
				length:0,
				Tilename:'',
				content:'',
				cover_img:'',
				type:0
			}
		},
		watch: {
			// "ALL": {
			// 	handler: function() {
			// 		if(this.ALL.length == this.newslist.length) {
			// 			this.allList = true
			// 		} else {
			// 			this.allList = false
			// 		}
			// 	},
			// 	deep: true
			// }
		},
		created:function(){
			this.getNewslist();

		},
		methods:{
			delNews(s){
				console.log(this.choseAll);
				for(var i in this.choseAll){
                this.$axios.post(this.HOST+'/admin/News/del',{
					id:i
				}).then((res)=>{
					console.log(res)
				})
				}


			},
			checkedAll(){
				this.allList=!this.allList
				var that=this;
				if(this.allList==true){
					// that.All1=[6,6];
					// 遍历数据,push到ALL里面
					var arr=[];

					// console.log(that.All1)
					that.newslist.forEach(function(val){
						arr.push(val.id)
					})
					this.choseAll=arr
					this.length=arr.length;
				}else{
					that.choseAll=[]
				}
			},
			tianjia(){
				this.flag.a=false
			},
			changeNews(b){
				this.flag.b=false
				this.newsdetail=this.newslist[b];
				this.$axios.post(this.HOST+'/admin/News/edit',{
					id:a,
					title_name:this.Tilename,
					content:this.content,
					cover_img:this.cover_img,
					type:this.type
				}).then((data)=>{
					console.log(data)

				})

			},
			lookNews(a){
				this.show=!this.show;
				// this.newsdetail=this.newslist[a];
				this.$axios.post(this.HOST+'/admin/News/getInfo',{
			      		id:a
			      	}).then((res)=>{
			      		this.newsdetail=res.data.data
			      		// console.log(this.newsdetail)

			      	})

			},
			hanlleCurrentChange(val){
				   this.currentPage = val;
			              // this.getData(this.currentPage, this.pagesize);
			},
			handleSizeChange(){

			},
			
			getNewslist(){
				
				this.$axios.post(this.HOST+'/admin/News/getList',{
			      		page:  this.currentPage,
			      		pagecount:this.pagesize
			      	}).then((res)=>{
			      		this.newslist=res.data.data.list;
			      		this.count=res.data.data.total_num
			      		console.log(res.data.data)

			      	})
			}
		}
	}
</script>
<style scoped>
.news-content{
	border:1px solid #bfbfbf;
}
.news-title{
	background-color: #eff0f5;
	height:62px;
	line-height: 62px;
	border-bottom:1px solid #bfbfbf;
}
.newslist{
	border-bottom:1px solid #bfbfbf;
	height:50px;
	line-height: 50px;
}
.news-title li{
	border-left:1px solid #bfbfbf;
	text-align: center;
}
.news-footer{
	line-height: 62px;
	background-color: #eff0f5;

}
.news-content input{
	width:15px;
	background-color:#fff;
	height:15px;
	border:none;
}
ul{
	overflow:hidden;
}
li{
	float:left;
	color:#6c6d6f;
	font-size: 20px;

}	

.el-pagination{
	float:right;
}
.el-pagination.is-background .el-pager li:not(.disabled).active{
	background-color: #688fd3;
}

/*隐藏*/
.hide{
	width:1000px;
	height:642px;
	border:1px solid #bfbfbf;
	position: fixed;
	top:200px;
	left:50%;
	margin-left: -25%;
	background-color: #fff;
	overflow-y: scroll;

}
.hide_content{
	overflow:hidden;
	padding:20px;
	box-sizing: border-box;
	
}

.hide_content p{
	font-size: 20px;
	color:#1a1a1a;
	line-height: 40px;
}

</style>