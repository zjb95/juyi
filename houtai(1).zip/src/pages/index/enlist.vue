<template>
	
<div>
<!-- 头部 -->
	<div style="overflow:hidden;">
	<div class="block">
	    <span class="demonstration">报名时间</span>
	    <el-date-picker
	      v-model="value6"
	      type="daterange"
	      range-separator="-"
	      :start-placeholder="startTime"
	      :end-placeholder="endTime">
	    </el-date-picker>
	  </div>
	  <div class="cha">
	      <p>关键字:<input type="text"></p>
	      <div><img src="../../assets/web/清除.png" height="41" width="94" alt=""></div>
	      <div><img src="../../assets/web/搜索.png" height="41" width="94" alt=""></div>
	    </div>
	    <div style="float:right;"><img src="../../assets/web/导出报名表.png" height="41" width="142" alt=""></div>
	    </div>

	    <!-- 列表 -->
<div class="listProduct"> 
<p class="list-title"style="">报名列表</p>
<ul class="list_title">
   <li style="width:10%;">照片</li>
   <li style="width:12%;">姓名</li>
   <li style="width:7%;">性别</li>
   <li style="width:20%;">基本资料</li>
   <li style="width:12.2%;">报名时间</li>
   <li style="width:20%;">特长标签</li>
   <li style="width:14%;">操作</li>
 </ul>
 <ul class="list_detail" v-for="(item,index) in detail ">
   <li style="width:10%;">
   	<img style="width:80px;height:106px;margin-top:22px;"src="../../assets/web/77oba.png" alt="">
   </li>
   <li style="width:12%;line-height:150px;">{{item.name}}</li>
   <li style="width:7%;line-height:150px;">{{item.gental}}</li>
   <li style="width:20%;box-sizing:border-box;padding:5px;text-align:left;">
   <p style="line-height:30px;">姓名:{{item.name}}</p>
   <p style="line-height:30px;">电话:{{item.phone}}</p>
   <p style="line-height:30px;width:100%;">邮箱:{{item.email}}</p>
   <p style="line-height:30px;">地址:{{item.dizhi}}</p>
   </li>
   <li style="width:12.2%;line-height:150px;">{{item.time}}</li>
   <li style="width:20%;line-height:50px;">{{item.hoppy}}</li>
   <li style="width:14%;line-height:75px;cursor:pointer;"><p @click="showDetail(item.id)">查看详情</p><p style="">删除</p></li>
 </ul>
</div>

<!-- 分页 -->
<el-pagination
  background
  layout="prev, pager, next,jumper"
  :page-size="pagesize"
  :current-page="currentPage"
  @size-change="handleSizeChange"
  @current-change="hanlleCurrentChange"
  :page-sizes="[10, 20, 30, 40]"
  :total="100">
</el-pagination>


<!-- 隐藏div -->
<div style="width:100%;min-height:100%;background-color:rgba(0,0,0,.5);position:fixed;top:0;left:0px;" v-show="!show">
<div class="hide">
	<p style="wdith:66px;line-height:66px;width:1000px;background-color:#eff0f5;text-align:center;">详情信息</p>
	<img style="position:absolute;top:76px;right:12px;cursor:pointer;" src="../../assets/web/加号.png" alt="" @click="show=true">
	<div class="hide_content">
		<img src="../../assets/web/77oba.png" alt="">
		<div>
		    <p>姓名:{{detailList.name}}</p>
		    <p>性别:{{detailList.gental}}</p>
		    <p>电话:{{detailList.phone}}</p>
		    <p>邮箱:{{detailList.email}}</p>
		    <p>地址:{{detailList.dizhi}}</p>
		    <p>特长:{{detailList.hoppy}}</p>
		    <p>报名时间:{{detailList.time}}</p>
	</div>
	</div>
</div>
</div>

  </div>
</template>
<script>
export default {
  data() {
    return {
      pagesize: 10,
      currentPage: 1,
      value6: "",
      startTime: "开始时间",
      endTime: "结束时间",
      detailList: {},
      show: true,
      detail: [
        {
          id: 0,
          name: "花花",
          gental: "男",
          phone: "122222222222",
          email: "121222222222@123.com",
          dizhi: "杭州市",
          time: "2018-3-21 10:59",
          hoppy: "唱歌,肚皮舞,脱口秀,讲笑话,弹钢琴"
        },
        {
          id: 1,
          name: "花花",
          gental: "男",
          phone: "122222222222",
          email: "121222222222@123.com",
          dizhi: "杭州市",
          time: "2018-3-21 10:59",
          hoppy: "唱歌,肚皮舞,脱口秀,讲笑话,弹钢琴"
        },
        {
          id: 2,
          name: "花花",
          gental: "男",
          phone: "122222222222",
          email: "121222222222@123.com",
          dizhi: "杭州市",
          time: "2018-3-21 10:59",
          hoppy: "唱歌,肚皮舞,脱口秀,讲笑话,弹钢琴"
        },
        {
          id: 3,
          name: "花花",
          gental: "男",
          phone: "122222222222",
          email: "121222222222@123.com",
          dizhi: "杭州市",
          time: "2018-3-21 10:59",
          hoppy: "唱歌,肚皮舞,脱口秀,讲笑话,弹钢琴"
        }
      ]
    };
  },
  created: function() {
    this.getData();
  },
  methods: {
    showDetail(a) {
      this.show = !this.show;
      this.detailList = this.detail[a];
    },
    hanlleCurrentChange(val) {
      this.currentPage = val;
      this.getData(this.currentPage, this.pagesize);
    },
    handleSizeChange() {},
    getData() {
      // this.$axios.post(this.HOST+'admin/Product/hotList',{
      // 	page:this.currentPage,
      //                    pagecount:this.pagesize
      //                            }).then((data) => {
      //               console.log(data.data.content.list)
      // })
    }
  }
};
</script>
<style scoped>
.hide {
  width: 1000px;
  height: 642px;
  border: 1px solid #bfbfbf;
  position: fixed;
  top: 200px;
  left: 50%;
  margin-left: -25%;
  background-color: #fff;
}
.hide_content {
  overflow: hidden;
  padding: 20px;
  box-sizing: border-box;
}
.hide_content > div {
  float: left;
  margin-left: 40px;
}
.hide_content p {
  font-size: 20px;
  color: #1a1a1a;
  line-height: 50px;
}
.hide_content img {
  width: 382px;
  height: 510px;
  float: left;
}
/*新闻列表*/
.listProduct {
  margin-top: 20px;
  border: 1px solid #bfbfbf;
}
.list-title {
  width: 100%;
  height: 66px;
  line-height: 66px;
  background-color: #eff0f5;
  text-align: center;
  font-size: 20px;
  border-bottom: 1px solid #bfbfbf;
}
.list_title {
  height: 62px;
  line-height: 62px;
  color: #6c6d6f;
  font-size: 20px;
  border-bottom: 1px solid #bfbfbf;
}
li {
  text-align: center;
  border-left: 1px solid #bfbfbf;
}
.list_detail {
  height: 150px;
  border-bottom: 1px solid #bfbfbf;
}
.list_detail li {
  height: 150px;
  color: #6c6d6f;
  font-size: 16px;
}
ul {
  overflow: hidden;
}
li {
  float: left;
}
.demonstration {
  font-size: 20px;
  color: #6c6d6f;
}
.block {
  float: left;
}
.cha {
  float: left;
  margin-left: 20px;
}
.cha p {
  float: left;
  font-size: 20px;
  color: #7d7d80;
}
.cha input {
  width: 200px;
  height: 40px;
  border: 1px solid #bfbfbf;
}
.cha div {
  margin-left: 10px;
  width: 94;
  height: 41px;
  float: left;
}
.el-date-editor--daterange.el-input,
.el-date-editor--daterange.el-input__inner,
.el-date-editor--timerange.el-input,
.el-date-editor--timerange.el-input__inner {
  width: 340px;
  border: 1px solid #bfbfbf;
}
.el-pagination {
  float: right;
}
.el-pagination.is-background .el-pager li:not(.disabled).active {
  background-color: #688fd3;
}
</style>