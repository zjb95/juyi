<template>
  <div class="hello">
  <div style="" class="juyi">
  	<!-- <img stylw="width:100%;"src="../assets/web/矩形1_50.png" alt=""> -->
  	<div  class="login">
  		<div style="position:relative;">
  		<img src="../assets/web/用户名.png" alt="">
  		<input type="text" style="position:absolute;top:0px;left:93px;color:#fff;font-size:20px;" v-model="userName">
  		</div>
  		<div style="position:relative;">
  		<img src="../assets/web/密码.png" alt="">
  		<input type="text"  style="position:absolute;top:0px;left:92px;color:#fff;font-size:20px;" v-model="userPwd">
  		</div>
  		<img src="../assets/web/登录.png" alt="" @click="enter">
  	</div>
  </div>


  </div>
</template>
<script>
import qs from 'qs'

export default {
  name: 'Login',

  data () {
    return {
    	userName:'admin',
    	userPwd:'123456',
    	status:0
   }
  },
  created:function(){
  	this.getCookie();

  },
  methods:{
  	setCookie(name,value,exdays){
		var exdate=new Date();
		exdate.setTime(exdate.getTime()+24*60*60*1000*exdays);
		document.cookie=name+"="+value+';expires'+exdate.toGMTString();
	},
	getCookie(){
		// console.log(document.cookie)
		if(document.cookie.length>0){
			var arr=document.cookie.split('; ');
			console.log(arr)
			for(var i=0;i<arr.length;i++){
				var arr2=arr[i].split('=');
				if(arr2[0]=='username'){
					this.jizhu=true;
					this.loginList.username=arr2[1]
				}
		     }
		}	
	},
	delCookie(){
		this.setCookie("","",-1)
	},
  	enter(){
  		var that=this;
  		this.$axios.post(this.HOST+"/admin/Login/login",{
  				user:this.userName,
  				password:this.userPwd
                      }).then((data)=>{
                      	var token=data.data.data.token;
                      	this.status=data.data.status;
  				if(this.status==1){
  				this.setCookie("token",token,7)
  			               this.$router.push({path:'enlist'})
  				}
  			})

  
  	}
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.juyi{
	width:100%;
	height:970px;
	background: url(../assets/web/矩形1_50.png);
	background-position: center;
	overflow:hidden;
}

.login{
	width:524px;
	margin:0 auto;
	margin-top:500px;

	text-align: center;
}
.login>div{
	overflow:hidden;
	margin-bottom: 38px;
}

.login>div>input{
	height:61px;
	width:431px;
	background-color:#626262;
	border:none;
	float: left
}

</style>
