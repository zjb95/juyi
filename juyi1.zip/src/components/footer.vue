<template>
  <div class="footer">
  <div class="footer-top">
<div style="width:1200px;margin:0 auto;padding:20px 0;overflow:hidden;">
	<img style="float:left;margin-top:30px;"src="../assets/oneImg/矢量智能对象 (2).png" alt="">
	<ul style="float:left;margin-left:50px;">
		<li>宜兴聚宜文化传媒有限公司</li>
		<li>电话:0510-87971011</li>
		<li>联系人:apple</li>
		<li>QQ:139615007</li>
		<li>邮箱:139615007@qq.com</li>
		<li>地址:宜兴市教育西路21号国际经贸大厦四楼</li>
	</ul>
	<div style="float:right;width:150px;">
	<img  src="../assets/oneImg/公众号二维码(1).png" alt="">
	<p style="color:#fff;width:150px;text-align:center;line-height:25px;">微信公众号</p>
	</div>

</div>
</div>
<div class="footer-bottom" style="background-color:#4d4848;height:52px;">
	<p style="width:1200px;margin:0 auto;line-height:52px;color:#fff;text-align:right;">版权所有:宜兴聚点传媒有限公司  苏ICP备:17022031 号 技术支持:杭州谦程网络有限公司</p>
</div>
  </div>
</template>

<script>
export default {
  name: 'Footer',
  data () {
    return {
    
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.footer{
	width:100%;
	background-color: #1f1f1f;
	
}
.footer-top{
	height:231px;

}
ul li{
	color: #fff;
	line-height: 30px;

}

</style>
